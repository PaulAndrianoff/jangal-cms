<?php

use Illuminate\Support\Facades\Route;
use Platform\Plugins\ActivityLogger\Controllers\LogController;

Route::middleware(['web', 'auth', 'is_admin'])->prefix('admin/logs')->group(function () {
    Route::get('/', [LogController::class, 'index'])->name('admin.logs.index');
    Route::get('/settings', [LogController::class, 'settings'])->name('admin.logs.settings');
    Route::post('/settings', [LogController::class, 'updateSettings'])->name('admin.logs.settings.update');
});